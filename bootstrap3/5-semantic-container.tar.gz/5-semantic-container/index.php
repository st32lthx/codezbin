<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Semantic Container</title>
    <meta name="viewport" content="width=device-width, maximum-scale=1.0" />
    <link rel="stylesheet/less" type="text/css" href="main.less" />
    <script src="less.js" type="text/javascript"></script>
</head>

<body>
    <div class="page">
        <section>
            <article class="left-navigation">
                <nav class="highlight">
                    <h1>Left</h1>
                </nav>
            </article>
            <article class="main-content">
                <article class="highlight">
                    <h2>right</h2>
                </article>
            </article>
        </section>
    </div>
</body>

</html>