$(function(){
	$(".my-tooltip").tooltip({
		'placement':'right',
		'delay':500
	});
})