// CompilingMexVisualStudio2010.h : main header file for the CompilingMexVisualStudio2010 DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CCompilingMexVisualStudio2010App
// See CompilingMexVisualStudio2010.cpp for the implementation of this class
//

class CCompilingMexVisualStudio2010App : public CWinApp
{
public:
	CCompilingMexVisualStudio2010App();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
