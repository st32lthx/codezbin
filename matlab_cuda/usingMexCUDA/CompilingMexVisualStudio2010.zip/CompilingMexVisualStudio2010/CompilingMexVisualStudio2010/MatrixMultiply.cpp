// This is the main DLL file.

#include "stdafx.h"

#include "mex.h"
#include <math.h>

// Implements a simple funtion that does an elemental multiplication of an matrix
void MultiplyMatrix(double multiplier, double *inputs, double *outputs, int mrows, int ncols)
{
	__try
	{
		for(int i = 0; i < mrows; i++)
		{
			for(int j = 0; j < ncols; j++)
			{
				double nbr = *(inputs + i*ncols + j);
				*(outputs + i*ncols + j) = nbr * multiplier;
			}
		}

	}
	__except(EXCEPTION_EXECUTE_HANDLER){
		int a = 0;	
	}// try / except
}


/* The gateway routine */
void mexFunction(int nlhs, mxArray *plhs[],
				 int nrhs, const mxArray *prhs[])
{
	double *outputs, *inputs;
	double multiplier;
	int mrows,ncols;

	/*  Check for proper number of arguments. */
	/* NOTE: You do not need an else statement when using
	mexErrMsgTxt within an if statement. It will never
	get to the else statement if mexErrMsgTxt is executed.
	(mexErrMsgTxt breaks you out of the MEX-file.) 
	*/
	if (nrhs != 2) 
		mexErrMsgTxt("Two inputs required. A vector and a multiplier");
	if (nlhs != 1) 
		mexErrMsgTxt("One output required. The resulting vector");

	/* Check to make sure the first input argument is a scalar. */
	/*if (!mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) ||
	mxGetN(prhs[0])*mxGetM(prhs[0]) != 1) {
	mexErrMsgTxt("Input x must be a scalar.");
	}*/

	/* Get the scalar inputs window, delay & mode. */
	multiplier = (int)mxGetScalar(prhs[1]);

	/* Create a pointer to the input matrix input. */
	inputs = mxGetPr(prhs[0]);

	/* Get the dimensions of the matrix input input. */
	mrows = mxGetM(prhs[0]);
	ncols = mxGetN(prhs[0]);

	/* Set the output pointer to the output matrix. */
	plhs[0] = mxCreateDoubleMatrix(mrows,ncols, mxREAL);

	/* Create a C pointer to a copy of the output matrix. */
	outputs = mxGetPr(plhs[0]);

	/* Call the C subroutine. */
	MultiplyMatrix(multiplier, inputs,outputs,mrows,ncols);
}